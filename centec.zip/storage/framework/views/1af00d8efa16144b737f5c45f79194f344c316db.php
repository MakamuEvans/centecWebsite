<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title>Sentimental Energy | Kenya - Cheap Reliable Solar Energy for All</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <meta name="description" content="Bootstrap 3 template for corporate business" />
    <!-- css -->
    <link href="<?php echo e(url("css/bootstrap.min.css")); ?>" rel="stylesheet" />
    <link href="<?php echo e(url("plugins/flexslider/flexslider.css")); ?>" rel="stylesheet" media="screen" />
    <link href="<?php echo e(url("css/cubeportfolio.min.css")); ?>" rel="stylesheet" />
    <link href="<?php echo e(url("css/style.css")); ?>" rel="stylesheet" />

    <!-- Theme skin -->
    <link id="t-colors" href="<?php echo e(url("skins/default.css")); ?>" rel="stylesheet" />

    <!-- boxed bg -->
    <link id="bodybg" href="<?php echo e(url("bodybg/bg1.css")); ?>" rel="stylesheet" type="text/css" />
    <link id="bodybg" href="<?php echo e(url("css/sentec.css")); ?>" rel="stylesheet" type="text/css" />

</head>
<body>
<div id="fb-root"></div>
<script>(function(d, s, id) {
        var js, fjs = d.getElementsByTagName(s)[0];
        if (d.getElementById(id)) return;
        js = d.createElement(s); js.id = id;
        js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.8&appId=1090278264384599";
        fjs.parentNode.insertBefore(js, fjs);
    }(document, 'script', 'facebook-jssdk'));</script>





<div id="wrapper">
    <!-- start header -->
    <header>
        <div class="top" style="padding: 0px">
            <div class="container" style="">
                <div class="row">
                    <div class="col-md-6">
                    </div>
                    <div class="col-md-6">
                        <ul class="social-network pull-right">
                            <li><a href="https://www.facebook.com/sentimentalenergy/" data-placement="bottom" style="color: green" title="Facebook"><i class="fa fa-facebook"></i></a></li>
                            <li><a href="https://twitter.com/SentecLtd" data-placement="bottom" style="color: green" title="Twitter"><i class="fa fa-twitter"></i></a></li>
                            <li><a href="#" data-placement="bottom" style="color: green" title="Linkedin"><i class="fa fa-linkedin"></i></a></li>
                            <li><a href="#" data-placement="bottom" style="color: green" title="Pinterest"><i class="fa fa-pinterest"></i></a></li>
                            <li><a href="#" data-placement="bottom" style="color: green" title="Google plus"><i class="fa fa-google-plus"></i></a></li>
                        </ul>
                        <div id="sb-search" class="sb-search" style="visibility: hidden">
                            <form>
                                <input class="sb-search-input" placeholder="Enter your search term..." type="text" value="" name="search" id="search">
                                <input class="sb-search-submit" type="submit" value="">
                                <span class="sb-icon-search" title="Click to start searching"></span>
                            </form>
                        </div>


                    </div>
                </div>
            </div>
        </div>
        <?php echo $__env->make('partials.nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    </header>
    <!-- end header -->

    <?php echo $__env->yieldContent('content'); ?>

    <?php echo $__env->make('partials.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<a href="#" class="scrollup"><i class="fa fa-angle-up active"></i></a>

<!-- Placed at the end of the document so the pages load faster -->
<script src="<?php echo e(url("js/jquery.min.js")); ?>"></script>
<script src="<?php echo e(url("js/modernizr.custom.js")); ?>"></script>
<script src="<?php echo e(url("js/jquery.easing.1.3.js")); ?>"></script>
<script src="<?php echo e(url("js/bootstrap.min.js")); ?>"></script>
<script src="<?php echo e(url("plugins/flexslider/jquery.flexslider-min.js")); ?>"></script>
<script src="<?php echo e(url("plugins/flexslider/flexslider.config.js")); ?>"></script>
<script src="<?php echo e(url("js/jquery.appear.js")); ?>"></script>
<script src="<?php echo e(url("js/stellar.js")); ?>"></script>
<script src="<?php echo e(url("js/classie.js")); ?>"></script>
<script src="<?php echo e(url("js/uisearch.js")); ?>"></script>
<script src="<?php echo e(url("js/jquery.cubeportfolio.min.js")); ?>"></script>
<script src="<?php echo e(url("js/google-code-prettify/prettify.js")); ?>"></script>
<script src="<?php echo e(url("js/animate.js")); ?>"></script>
<script src="<?php echo e(url("js/custom.js")); ?>"></script>


</body>
</html>