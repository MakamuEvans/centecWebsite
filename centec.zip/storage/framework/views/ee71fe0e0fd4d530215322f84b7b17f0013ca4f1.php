<div class="row" style="margin: 10%;text-align: left">
    <div class="row" style="padding-left: 0%">
        <a class="twitter-timeline" data-height="300" data-theme="light" href="https://twitter.com/SentecLtd">Tweets from Sentecltd</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
    </div>
    <div class="fb-page" data-href="https://www.facebook.com/sentimentalenergy/" data-tabs="timeline" data-height="350" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/idleyouthscorner/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/idleyouthscorner/">Sentimental Energy.</a></blockquote></div>
   <br>
    <h4 style="color: #fed136">Read More</h4>
    <h5>Solar Explained</h5>
    <a href="<?php echo e(url('how-solar-works')); ?>">
        <i class="fa fa-chevron-right">How Solar Works</i><br>
    </a>
    <a href="<?php echo e(url('the-pv-module')); ?>">
        <i class="fa fa-chevron-right">The PV System</i><br>
    </a>
    <a href="<?php echo e(url('why-go-solar')); ?>">
        <i class="fa fa-chevron-right">Why Go Solar</i><br><br>
    </a>
    <hr>
    <h5>Our Downloads</h5>
    <a href="<?php echo e(url('download/brochure')); ?>"><i class="fa fa-chevron-right">Bronchure</i></a><br><br>
    <a href="<?php echo e(url('download/water-heating-catalog')); ?>"><i class="fa fa-chevron-right">Water Heating Catalog</i></a><br><br>

</div>