<div id="main-slider" class="main-slider flexslider">
    <ul class="slides">
        <li>
            <img src="<?php echo e(url('img/green.jpg')); ?>" alt="" />
            <div class="flex-caption">
                <h3>Affordable Solar</h3>
                <p>We Provide Affordable, Clean And Reliable Solar Energy to All</p>
            </div>
        </li>
        <li>
            <img src="<?php echo e(url('img/solar.jpg')); ?>" alt="" />
            <div class="flex-caption">
                <h3>Professionalism</h3>
                <p>We ara a Duly Registered and Accredited Company in Kenya. Being Professional is our Expertise</p>
            </div>
        </li>
        <li>
            <img src="<?php echo e(url('img/customer.jpg')); ?>" alt="" />
            <div class="flex-caption">
                <h3>Get in Touch</h3>
                <p>Have a Question, Requesting our quotes?. Talk to us</p>
                <a href="<?php echo e(url('contact-us')); ?>" class="btn btn-success">Click Here</a>
            </div>
        </li>
    </ul>
</div>