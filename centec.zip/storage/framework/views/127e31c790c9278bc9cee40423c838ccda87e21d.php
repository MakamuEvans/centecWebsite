<div id="main-slider" class="main-slider flexslider">
    <ul class="slides">
        <li>
            <img src="<?php echo e(url('img/sentimental1.png')); ?>" alt="" style="width: 100%;height: auto"/>
            <div class="flex-caption">
                <h3>Affordable Solar</h3>
                <p>We Provide Affordable, Clean And Reliable Solar Energy to All</p>
            </div>
        </li>
        <li>
            <img src="<?php echo e(url('img/consulting1.png')); ?>" alt="" />
            <div class="flex-caption">
                <h3>Get in Touch</h3>
                <p>Have a Question, Requesting our quotes?. Talk to us</p>
                <a href="<?php echo e(url('contact-us')); ?>" class="btn btn-success">Click Here</a>
            </div>
        </li>
    </ul>
</div>