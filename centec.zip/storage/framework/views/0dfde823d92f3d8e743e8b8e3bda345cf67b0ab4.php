<?php $__env->startSection('content'); ?>
    <section id="inner-headline">
        <div class="container">
            <div class="row">
                <div class="col-lg-12">
                    <ul class="breadcrumb">
                        <li><a href="#"><i class="fa fa-home"></i></a><i class="icon-angle-right"></i></li>
                        <li class="active">Our Team</li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
    <section id="content">
        <div class="container">
            <div class="row">
                <div class="col-lg-8" style="text-align: center">
                    
                    <div class="row">
                        <div class="col-lg-4">
                            <img src="<?php echo e(url('img/paul.jpg')); ?>" class="img-responsive"
                                 style="border-radius: 50px;">
                        </div>
                        <div class="col-lg-8">
                            <h4 style="text-align: left">Paul Simiyu Mabonga <span>&#8213; Managing Director and Founder</span></h4>
                            <div class="testimonialslide clearfix flexslider">
                                <ul class="slides">
                                    <li>
                                        <blockquote>
                                            Designation - East Africa Region
                                        </blockquote>
                                        <blockquote>
                                            P.O Box 103690-00101,
                                            Nairobi.
                                            <a href="mailto:pmabonga@gmail.com">pmabonga@gmail.com</a>
                                            <a href="mailto:simiyu@sentecltd.com">simiyu@sentecltd.com</a>
                                            0725 -445-459.
                                        </blockquote>
                                    </li>
                                    <li>
                                        <span class="pullquote-left" style="text-align: left">
                                            <span><u>Qualifications</u></span><br>
                                            BSC:MECHANICAL & PRODUCTION ENG (MOI UNIVERSITY)<br>
                                            MBA :STRATEGIC MANAGEMENT (JKUAT)<br>
                                            DIPLOMA:PROJECTS MANAGEMENT(MUA).<br><br>

                                            <span><u>Experience</u></span><br>
                                           SIx(6) Years

                                        </span>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-4">
                            <img src="<?php echo e(url('img/chesire.jpg')); ?>" class="img-responsive"
                                 style="border-radius: 50px;">
                        </div>
                        <div class="col-lg-8">
                            <h4 style="text-align: left">Chesire Kipkemboi Edwin <span>&#8213; Director Finance and Strategy</span></h4>
                            <div class="testimonialslide clearfix flexslider">
                                <ul class="slides">
                                    <li>
                                        <blockquote>
                                            Designation - East Africa Region
                                        </blockquote>
                                        <blockquote>
                                            P.O Box 103690-00101,<br>
                                            Nairobi.<br>
                                            <a href="mailto:chesireedwin@gmail.com">chesireedwin@gmail.com</a> <br>
                                            <a href="mailto:chesire@sentecltd.com">chesire@sentecltd.com</a> <br>
                                            0723 -696-146.
                                        </blockquote>
                                    </li>
                                    <li>
                                        <span class="pullquote-left" style="text-align: left">
                                             Chesire Kipkemboi Edwin is a holder of B. Tech. in Mechanical and Production Engineering form Moi University and masters in Energy Technology from Jomo Kenyatta University of Agriculture and Technology.  He is a registered graduate engineer with the Engineers Registration Board of Kenya. He has expansive knowledge of the Kenya’s energy sector having worked with the Ministry of Energy and Petroleum for the past 6 years. He is has undertaken key tasks including the performing prefeasibility study for Kenya’s Nuclear Power Programme, Development of Energy Bill 2015 and Development of the long-term energy plan for the country: the Least Cost Power Development Plan
                                        </span>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-4">
                            <img src="<?php echo e(url('img/photo.png')); ?>" class="img-responsive"
                                 style="border-radius: 50px;">
                        </div>
                        <div class="col-lg-8">
                            <h4 style="text-align: left">Johannes Oos <span>&#8213; Technical Director</span></h4>
                            <div class="testimonialslide clearfix flexslider">
                                <ul class="slides">
                                    <li>
                                        <blockquote>
                                            Designation - East Africa Region
                                        </blockquote>
                                        <blockquote>
                                            P.O Box 103690-00101,
                                            Nairobi.
                                            <a href="mailto:oosjoh@gmail.com">oosjoh@gmail.com</a>
                                            <a href="mailto:joos@sentecltd.com">joos@sentecltd.com</a>
                                            0725 -445-459.
                                        </blockquote>
                                    </li>
                                    <li>
                                        <span class="pullquote-left" style="text-align: left">
                                            <span><u>Qualifications</u></span><br>
                                            CERTIFICATE IN ELECTRICAL INSTALATIONS<br>
                                            DIPLOMA IN ELECTRICAL INSTALLATIONS <br>
                                            BACHELORS IN ELECTRICAL ENGINEERING<br><br>


                                            <span><u>Experience</u></span><br>
                                           Twelve(12) Years

                                        </span>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>



                    <div class="row">
                        <div class="col-lg-4">
                            <img src="<?php echo e(url('img/photo.png')); ?>" class="img-responsive"
                                 style="border-radius: 50px;">
                        </div>
                        <div class="col-lg-8">
                            <h4 style="text-align: left">Isabella Simiyu <span>&#8213; </span></h4>
                            <div class="testimonialslide clearfix flexslider">
                                <ul class="slides">
                                    <li>
                                        <blockquote>
                                            Designation - North Rift Kenya
                                        </blockquote>
                                        <blockquote>
                                            P.O Box 103690-00101,
                                            Nairobi.
                                            
                                        </blockquote>
                                    </li>
                                    <li>
                                        <span class="pullquote-left" style="text-align: left">
                                            <span><u>Qualifications</u></span><br>
                                            BSC :INDUTRIAL MANUFACTURNG & <br>
                                            PROCESSING ENGINEERING (MOI UNI).<br>
                                            DIPLOMA IN SALES AND MARKETING
                                            <br><br>


                                            <span><u>Experience</u></span><br>
                                           Six(6) Years

                                        </span>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-lg-4">
                            <img src="<?php echo e(url('img/photo.png')); ?>" class="img-responsive"
                                 style="border-radius: 50px;">
                        </div>
                        <div class="col-lg-8">
                            <h4 style="text-align: left">Anthony Mwangi Kinyua <span>&#8213; </span></h4>
                            <div class="testimonialslide clearfix flexslider">
                                <ul class="slides">
                                    <li>
                                        <blockquote>
                                            Designation - Western Kenya
                                        </blockquote>
                                        <blockquote>
                                            P.O Box 103690-00101,
                                            Nairobi.
                                            
                                        </blockquote>
                                    </li>
                                    <li>
                                        <span class="pullquote-left" style="text-align: left">
                                            <span><u>Qualifications</u></span><br>
                                            BSC: MECHANCAL AND PRODUCTION ENGINEERING

                                            <br><br>


                                            <span><u>Experience</u></span><br>
                                           Six(6) Years

                                        </span>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-lg-4">
                            <img src="<?php echo e(url('img/photo.png')); ?>" class="img-responsive"
                                 style="border-radius: 50px;">
                        </div>
                        <div class="col-lg-8">
                            <h4 style="text-align: left">Aaron Wambulwa <span>&#8213; Accountys and Administration</span></h4>
                            <div class="testimonialslide clearfix flexslider">
                                <ul class="slides">
                                    <li>
                                        <blockquote>
                                            Designation -
                                        </blockquote>
                                        <blockquote>
                                            P.O Box 103690-00101,
                                            Nairobi.
                                            
                                        </blockquote>
                                    </li>
                                    <li>
                                        <span class="pullquote-left" style="text-align: left">
                                            <span><u>Qualifications</u></span><br>
                                                KATC <br>
                                                CPA 3 <br>
                                                DIPLOMA IN SALES AND MARKETING
                                            <br><br>


                                            <span><u>Experience</u></span><br>
                                           Five(5) Years

                                        </span>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>


                    <div class="row">
                        <div class="col-lg-4">
                            <img src="<?php echo e(url('img/photo.png')); ?>" class="img-responsive"
                                 style="border-radius: 50px;">
                        </div>
                        <div class="col-lg-8">
                            <h4 style="text-align: left">Kepher Ochieng <span>&#8213; </span></h4>
                            <div class="testimonialslide clearfix flexslider">
                                <ul class="slides">
                                    <li>
                                        <blockquote>
                                            Designation - Eastern Kenya
                                        </blockquote>
                                        <blockquote>
                                            P.O Box 103690-00101,
                                            Nairobi.
                                            
                                        </blockquote>
                                    </li>
                                    <li>
                                        <span class="pullquote-left" style="text-align: left">
                                            <span><u>Qualifications</u></span><br>
                                                BSC: MECHANICAL AND ELECTRICAL ENGINEERING
                                            <br><br>


                                            <span><u>Experience</u></span><br>
                                           Intern

                                        </span>

                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>

                </div>

                <div class="col-lg-4">
                    <?php echo $__env->make('partials.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                </div>

            </div>


        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>