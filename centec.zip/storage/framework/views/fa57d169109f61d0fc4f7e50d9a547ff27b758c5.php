<footer style="background-color: yellow">
    <div class="container">
        <div class="row" style="text-align: center">
            
            <div class="col-sm-4 col-lg-4">
                <hr>
                <div class="widget">
                    <div class="row">
                        <address>
                            <strong>Sentimental Energy Ltd</strong><br>
                            Nextgen Mall, <br>
                            2nd floor,<br>
                            Mombasa road,<br>
                            Nairobi Kenya |<br>
                        </address>
                        <p>
                            <a href="mailto:info@sentecltd.com">info@sentecltd.com</a> |<br>

                            +254-725 445459 , 0738261640, +254-723696146
                        </p>
                    </div>
                </div>
            </div>
            <div class="col-sm-4 col-lg-4">
                <hr>
                <div class="widget">
                    <h4>Downloads</h4>
                    <ul class="link-list">
                        <li><a href="<?php echo e(url('download/brochure')); ?>">Our Brochure</a></li>
                        <li><a href="<?php echo e(url('download/water-heating-catalog')); ?>">Water heating Catalog</a></li>
                    </ul>
                </div>

                <div class="widget">
                    <h4>Read Latest...</h4>
                    <ul class="link-list">
                        <li><a href="<?php echo e(url('why-go-solar')); ?>">Why Go Solar?</a></li>
                        <li><a href="<?php echo e(url('how-solar-works')); ?>">How Solar Works.</a></li>
                        <li><a href="<?php echo e(url('the-pv-module')); ?>">The PV System.</a></li>
                    </ul>
                </div>

            </div>
            <div class="col-sm-4 col-lg-4">
                <hr>
                <div class="widget">
                    <h4>Legal</h4>
                    <ul class="link-list">
                        <li>&copy; 2017, Sentimental Energy</li>
                        <li><a href="#">Terms and conditions</a></li>
                        <li><a href="#">Privacy policy</a></li>
                        <li><a href="#">Career center</a></li>
                        <li><a href="<?php echo e(url('our-team')); ?>">Our Team</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>