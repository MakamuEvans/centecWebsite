<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<h2>A Message was received from sentecltd website</h2>


<div>
    Details of the Message:<br><br>
</div>
<div>From: <?php echo e($name); ?></div>
<div>Whose contact details are: <?php echo e($email); ?>, <?php echo e($phone); ?></div>

<div>Message: <?php echo e($comments); ?> </div><br><br>


</body>
</html>