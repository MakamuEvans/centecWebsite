<aside class="right-sidebar">
    <div class="widget">
        <h5 class="widgetheading">Information</h5>
        <ul class="recent">
            <li>
                <img src="<?php echo e(url('img/thumb1.jpg')); ?>" class="pull-left" alt="" />
                <h6>Why Go Solar?</h6>
                <p>
                    <a href="<?php echo e(url('why-go-solar')); ?>">
                        Click here to know why you should...
                    </a>
                </p>
            </li>
            <li>
                <img src="<?php echo e(url('img/thumb1.jpg')); ?>" class="pull-left" alt="" />
                <h6>Solar Explained</h6>
                <p>
                    <a href="<?php echo e(url('solar-explained')); ?>">
                        Click here to get more information...
                    </a>
                </p>
            </li>
            <li>
                <img src="<?php echo e(url('img/thumb1.jpg')); ?>" class="pull-left" alt="" />
                <h6>The PV System</h6>
                <p>
                    <a href="<?php echo e(url('the-pv-system')); ?>">
                        Click here to get more information...
                    </a>
                </p>
            </li>
        </ul>
    </div>
    <div class="widget">
        <h5 class="widgetheading">Social</h5>
        <div class="row" style="padding-left: 0%">
            <a class="twitter-timeline" data-height="300" data-theme="light" href="https://twitter.com/SentecLtd">Tweets from Sentecltd</a> <script async src="//platform.twitter.com/widgets.js" charset="utf-8"></script>
        </div>
        <div class="fb-page" data-href="https://www.facebook.com/sentimentalenergy/" data-tabs="timeline" data-height="350" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/idleyouthscorner/" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/idleyouthscorner/">Sentimental Energy.</a></blockquote></div>

    </div>
</aside>