<!DOCTYPE html>
<html lang="en-US">
<head>
    <meta charset="utf-8">
</head>
<body>
<h2>A Message was received from sentecltd website</h2>


<div>
    Details of the Message:<br><br>
</div>
<div>From: {{ $name }}</div>
<div>Whose contact details are: {{ $email }}, {{$phone}}</div>

<div>Message: {{ $comments}} </div><br><br>


</body>
</html>