<?php $__env->startSection('content'); ?>
        <!-- Header -->
<div class="col-md-10 col-md-offset-1" style="background-color: white">
    <div class="row" style="margin-top: 150px;margin-left: 10px;margin-right: 10px">
        <div class="col-md-8">
            <div class="row" style="text-align: left">
                <ol class="breadcrumb" style="margin-bottom: 0%">
                    <li><a href="<?php echo e(url('/')); ?>">Home</a></li>
                    <li><a href="#">Our Partners</a></li>
                </ol>
            </div>
            <h2 class="text-muted" style="text-align: center">Our Partners</h2>



        </div>
        <div class="col-md-4">
            <?php echo $__env->make('sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>