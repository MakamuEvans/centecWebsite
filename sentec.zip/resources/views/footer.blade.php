<footer style="padding-top: 0%;padding-bottom: 0%;text-align: center;background-color: grey">
    <div class="row" style="margin-left: 10px;padding-top: 5%;padding-bottom: 5%">
        <div class="col-md-6">
            <hr>
        </div>
        <div class="col-md-6" style="padding-right: 10px">
            <hr>
        </div>
        <div class="col-md-4" style="color: white">
            SILKWOOD office suite, <br>
            5th floor,<br>
            Ngong road,<br>
            Nairobi Kenya |<br>

            <a href="mailto:info@sentecltd.com">info@sentecltd.com</a> |<br>

            +254-725 445459 , 0738261640
        </div>
        <div class="col-md-4">
                <div class="row">
                    <a href="{{url('view/brochure')}}">Download our Brochure</a><br><br>
                </div>
                <ul class="list-inline social-buttons">
                    <li><a href="#"><i class="fa fa-twitter"></i></a>
                    </li>
                    <li><a href="#"><i class="fa fa-facebook"></i></a>
                    </li>
                    <li><a href="#"><i class="fa fa-linkedin"></i></a>
                    </li>
                </ul>
        </div>
        <div class="col-md-4">
                <ul class="list-inline quicklinks">
                    <li><a href="#">Terms and Conditions</a>
                    </li>
                </ul>
                <div class="row">
                    <span class="copyright">Copyright &copy; Sentimental Energy</span><br>
                    2016
                </div>
        </div>
    </div>
</footer>